console.log('content script start');

// Inject the main script
var s = document.createElement('script');
s.src = chrome.runtime.getURL('injected.js');
s.onload = function () {
    this.remove();
};
(document.head || document.documentElement).appendChild(s);

let latestRawData = null;
let pendingQuestions = [];

// Core question processing
function processQuestions(rawData) {
    if (!rawData || !Array.isArray(rawData.questions)) return;

    // Track any missing questions
    pendingQuestions = [];

    rawData.questions.forEach(q => {
        if (q.__t !== 'MCQ') return;

        console.log(`Question: ${q.title}`);
        q.choices.forEach(choice => {
            const isCorrect = choice.isCorrect ? '✅' : '❌';
            console.log(` - ${choice.choice} [${isCorrect}]`);
        });

        const questionEls = Array.from(document.querySelectorAll('*')).filter(el =>
            el.textContent.trim() === q.title.trim()
        );

        if (questionEls.length === 0) {
            console.warn('⚠️ Could not find element for question:', q.title);
            pendingQuestions.push(q); // Mark for retry
            return;
        }

        const questionEl = questionEls[0];
        const container = questionEl.closest('.question-container') || questionEl.parentElement;

        q.choices.forEach(choice => {
            const choiceText = choice.choice.trim();

            const answerEls = Array.from(container.querySelectorAll('*')).filter(el =>
                el.childNodes.length === 1 &&
                el.childNodes[0].nodeType === Node.TEXT_NODE &&
                el.textContent.trim() === choiceText
            );

            answerEls.forEach(el => {
                if (choice.isCorrect && !el.textContent.includes('✅')) {
                    el.textContent = choiceText + ' ✅';
                }
            });
        });
    });
}

// Retry processing any previously missing questions
function retryPendingQuestions() {
    if (pendingQuestions.length === 0) return;

    console.log('🔁 Retrying pending questions...');
    const questionsToRetry = [...pendingQuestions];
    pendingQuestions = []; // Reset before retrying

    questionsToRetry.forEach(q => {
        const questionEls = Array.from(document.querySelectorAll('*')).filter(el =>
            el.textContent.trim() === q.title.trim()
        );

        if (questionEls.length === 0) {
            console.warn('⚠️ Still missing question:', q.title);
            pendingQuestions.push(q); // Still not found
            return;
        }

        const questionEl = questionEls[0];
        const container = questionEl.closest('.question-container') || questionEl.parentElement;

        q.choices.forEach(choice => {
            const choiceText = choice.choice.trim();

            const answerEls = Array.from(container.querySelectorAll('*')).filter(el =>
                el.childNodes.length === 1 &&
                el.childNodes[0].nodeType === Node.TEXT_NODE &&
                el.textContent.trim() === choiceText
            );

            answerEls.forEach(el => {
                if (choice.isCorrect && !el.textContent.includes('✅')) {
                    el.textContent = choiceText + ' ✅';
                }
            });
        });
    });
}

// Handle message from injected script
window.addEventListener('message', function (e) {
    console.log('content script receive ' + e.type);

    try {
        if (!e.data || !e.data.data) {
            console.warn('⚠️ Received message without valid data');
            return;
        }

        let rawData;

        if (typeof e.data.data === 'string') {
            try {
                rawData = JSON.parse(e.data.data);
            } catch (jsonErr) {
                console.warn('⚠️ Skipping invalid JSON string:', e.data.data);
                return;
            }
        } else {
            rawData = e.data.data;
        }

        latestRawData = rawData;
        processQuestions(rawData);

    } catch (err) {
        console.error('❌ Could not parse message data:', err);
    }
});

// Wait for <body> to exist before observing
function startObserverWhenReady() {
    if (document.body) {
        const observer = new MutationObserver(() => {
            if (latestRawData) {
                retryPendingQuestions();
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        console.log('✅ MutationObserver is now watching the DOM.');
    } else {
        setTimeout(startObserverWhenReady, 100);
    }
}

startObserverWhenReady();
